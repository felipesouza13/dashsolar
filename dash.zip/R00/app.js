// Sistema de Gestão para Empresa de Engenharia Elétrica
class EngElectricaApp {
    constructor() {
        this.transactions = JSON.parse(localStorage.getItem('transactions')) || [];
        this.quotes = JSON.parse(localStorage.getItem('quotes')) || [];
        this.currentEditingTransaction = null;
        this.currentEditingQuote = null;
        
        this.categoryMap = {
            entrada: ["Projetos Elétricos", "Energia Solar", "Laudos", "Execução de Serviços"],
            saida: ["Materiais", "Pessoal", "Aluguel", "Equipamentos", "Tributos", "Outras Despesas"]
        };

        this.statusMap = {
            entrada: ["Recebido", "A Receber", "Vencido"],
            saida: ["Pago", "A Pagar", "Vencido"]
        };

        this.quoteStatuses = ["Prospecção", "Proposta Enviada", "Negociação", "Aguardando Decisão", "Fechado-Ganho", "Fechado-Perdido"];

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.setupMasks();
        this.renderDashboard();
        this.renderTransactions();
        this.renderQuotes();
        this.updateDashboardKPIs();
        this.renderCharts();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const tab = e.target.getAttribute('data-tab');
                this.switchTab(tab);
            });
        });

        // Transaction form
        document.getElementById('add-transaction-btn').addEventListener('click', () => {
            this.openTransactionModal();
        });

        document.getElementById('close-transaction-modal').addEventListener('click', () => {
            this.closeTransactionModal();
        });

        document.getElementById('cancel-transaction').addEventListener('click', () => {
            this.closeTransactionModal();
        });

        document.getElementById('transaction-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveTransaction();
        });

        document.getElementById('transaction-type').addEventListener('change', (e) => {
            this.updateTransactionCategories(e.target.value);
        });

        // Quote form
        document.getElementById('add-quote-btn').addEventListener('click', () => {
            this.openQuoteModal();
        });

        document.getElementById('close-quote-modal').addEventListener('click', () => {
            this.closeQuoteModal();
        });

        document.getElementById('cancel-quote').addEventListener('click', () => {
            this.closeQuoteModal();
        });

        document.getElementById('quote-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveQuote();
        });

        // Filters
        document.getElementById('filter-tipo').addEventListener('change', () => {
            this.renderTransactions();
        });

        document.getElementById('filter-status').addEventListener('change', () => {
            this.renderTransactions();
        });

        document.getElementById('filter-data-inicio').addEventListener('change', () => {
            this.renderTransactions();
        });

        document.getElementById('filter-data-fim').addEventListener('change', () => {
            this.renderTransactions();
        });

        document.getElementById('clear-filters-btn').addEventListener('click', () => {
            this.clearFilters();
        });

        // Quote filters
        document.getElementById('filter-quote-status').addEventListener('change', () => {
            this.renderQuotes();
        });

        document.getElementById('filter-quote-setor').addEventListener('change', () => {
            this.renderQuotes();
        });

        document.getElementById('clear-quote-filters-btn').addEventListener('click', () => {
            this.clearQuoteFilters();
        });

        // Export buttons
        document.getElementById('export-financial-btn').addEventListener('click', () => {
            this.exportFinancialData();
        });

        document.getElementById('export-crm-btn').addEventListener('click', () => {
            this.exportCRMData();
        });

        document.getElementById('backup-btn').addEventListener('click', () => {
            this.createBackup();
        });

        document.getElementById('restore-btn').addEventListener('click', () => {
            document.getElementById('restore-input').click();
        });

        document.getElementById('restore-input').addEventListener('change', (e) => {
            this.restoreBackup(e.target.files[0]);
        });

        // Modal outside click
        document.getElementById('transaction-modal').addEventListener('click', (e) => {
            if (e.target.id === 'transaction-modal') {
                this.closeTransactionModal();
            }
        });

        document.getElementById('quote-modal').addEventListener('click', (e) => {
            if (e.target.id === 'quote-modal') {
                this.closeQuoteModal();
            }
        });
    }

    setupMasks() {
        // Money mask for all money inputs
        document.querySelectorAll('.money-mask').forEach(input => {
            input.addEventListener('input', (e) => {
                this.applyMoneyMask(e.target);
            });
        });

        // Set today as default date
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('transaction-date').value = today;
    }

    applyMoneyMask(input) {
        let value = input.value.replace(/\D/g, '');
        value = (parseFloat(value) / 100).toFixed(2);
        value = value.replace('.', ',');
        value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        input.value = `R$ ${value}`;
    }

    parseMoneyValue(value) {
        return parseFloat(value.replace('R$ ', '').replace(/\./g, '').replace(',', '.')) || 0;
    }

    formatMoney(value) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value);
    }

    switchTab(tabName) {
        // Update nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`).classList.add('active');

        // Update data when switching to dashboard
        if (tabName === 'dashboard') {
            this.updateDashboardKPIs();
            this.renderCharts();
        }
    }

    // Transaction Management
    openTransactionModal(transaction = null) {
        this.currentEditingTransaction = transaction;
        const modal = document.getElementById('transaction-modal');
        const form = document.getElementById('transaction-form');
        const title = document.getElementById('transaction-modal-title');

        form.reset();

        if (transaction) {
            title.textContent = 'Editar Transação';
            document.getElementById('transaction-date').value = transaction.date;
            document.getElementById('transaction-type').value = transaction.type;
            this.updateTransactionCategories(transaction.type);
            document.getElementById('transaction-category').value = transaction.category;
            document.getElementById('transaction-value').value = this.formatMoney(transaction.value);
            document.getElementById('transaction-client').value = transaction.client || '';
            document.getElementById('transaction-status').value = transaction.status;
            document.getElementById('transaction-description').value = transaction.description;
            document.getElementById('transaction-observations').value = transaction.observations || '';
        } else {
            title.textContent = 'Nova Transação';
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('transaction-date').value = today;
        }

        modal.classList.add('active');
    }

    closeTransactionModal() {
        document.getElementById('transaction-modal').classList.remove('active');
        this.currentEditingTransaction = null;
    }

    updateTransactionCategories(type) {
        const categorySelect = document.getElementById('transaction-category');
        const statusSelect = document.getElementById('transaction-status');

        categorySelect.innerHTML = '<option value="">Selecione</option>';
        statusSelect.innerHTML = '<option value="">Selecione</option>';

        if (type && this.categoryMap[type]) {
            this.categoryMap[type].forEach(category => {
                const option = document.createElement('option');
                option.value = category;
                option.textContent = category;
                categorySelect.appendChild(option);
            });

            this.statusMap[type].forEach(status => {
                const option = document.createElement('option');
                option.value = status;
                option.textContent = status;
                statusSelect.appendChild(option);
            });
        }
    }

    saveTransaction() {
        const form = document.getElementById('transaction-form');
        const formData = new FormData(form);

        const transaction = {
            id: this.currentEditingTransaction ? this.currentEditingTransaction.id : Date.now(),
            date: document.getElementById('transaction-date').value,
            type: document.getElementById('transaction-type').value,
            category: document.getElementById('transaction-category').value,
            value: this.parseMoneyValue(document.getElementById('transaction-value').value),
            client: document.getElementById('transaction-client').value,
            status: document.getElementById('transaction-status').value,
            description: document.getElementById('transaction-description').value,
            observations: document.getElementById('transaction-observations').value
        };

        if (this.currentEditingTransaction) {
            const index = this.transactions.findIndex(t => t.id === this.currentEditingTransaction.id);
            this.transactions[index] = transaction;
        } else {
            this.transactions.push(transaction);
        }

        this.saveToStorage();
        this.renderTransactions();
        this.updateDashboardKPIs();
        this.renderCharts();
        this.closeTransactionModal();
        this.showNotification('Transação salva com sucesso!', 'success');
    }

    deleteTransaction(id) {
        if (confirm('Tem certeza que deseja excluir esta transação?')) {
            this.transactions = this.transactions.filter(t => t.id !== id);
            this.saveToStorage();
            this.renderTransactions();
            this.updateDashboardKPIs();
            this.renderCharts();
            this.showNotification('Transação excluída com sucesso!', 'success');
        }
    }

    renderTransactions() {
        const tbody = document.getElementById('transactions-table-body');
        let filteredTransactions = this.getFilteredTransactions();

        tbody.innerHTML = '';

        filteredTransactions.forEach(transaction => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${new Date(transaction.date).toLocaleDateString('pt-BR')}</td>
                <td><span class="status-badge ${transaction.type}">${transaction.type === 'entrada' ? 'Entrada' : 'Saída'}</span></td>
                <td>${transaction.category}</td>
                <td>${transaction.description}</td>
                <td>${this.formatMoney(transaction.value)}</td>
                <td><span class="status-badge ${transaction.status.toLowerCase().replace(' ', '-')}">${transaction.status}</span></td>
                <td class="actions">
                    <button class="btn btn--sm btn--secondary" onclick="app.openTransactionModal(${JSON.stringify(transaction).replace(/"/g, '&quot;')})">Editar</button>
                    <button class="btn btn--sm btn--outline" onclick="app.deleteTransaction(${transaction.id})">Excluir</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    getFilteredTransactions() {
        let filtered = [...this.transactions];

        const typeFilter = document.getElementById('filter-tipo').value;
        const statusFilter = document.getElementById('filter-status').value;
        const startDate = document.getElementById('filter-data-inicio').value;
        const endDate = document.getElementById('filter-data-fim').value;

        if (typeFilter) {
            filtered = filtered.filter(t => t.type === typeFilter);
        }

        if (statusFilter) {
            filtered = filtered.filter(t => t.status === statusFilter);
        }

        if (startDate) {
            filtered = filtered.filter(t => t.date >= startDate);
        }

        if (endDate) {
            filtered = filtered.filter(t => t.date <= endDate);
        }

        return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    }

    clearFilters() {
        document.getElementById('filter-tipo').value = '';
        document.getElementById('filter-status').value = '';
        document.getElementById('filter-data-inicio').value = '';
        document.getElementById('filter-data-fim').value = '';
        this.renderTransactions();
    }

    // Quote Management
    openQuoteModal(quote = null) {
        this.currentEditingQuote = quote;
        const modal = document.getElementById('quote-modal');
        const form = document.getElementById('quote-form');
        const title = document.getElementById('quote-modal-title');

        form.reset();

        if (quote) {
            title.textContent = 'Editar Orçamento';
            document.getElementById('quote-id').value = quote.quoteId;
            document.getElementById('quote-client').value = quote.client;
            document.getElementById('quote-contact').value = quote.contact || '';
            document.getElementById('quote-email').value = quote.email || '';
            document.getElementById('quote-phone').value = quote.phone || '';
            document.getElementById('quote-sector').value = quote.sector;
            document.getElementById('quote-value').value = this.formatMoney(quote.value);
            document.getElementById('quote-probability').value = quote.probability;
            document.getElementById('quote-status').value = quote.status;
            document.getElementById('quote-send-date').value = quote.sendDate || '';
            document.getElementById('quote-followup-date').value = quote.followupDate || '';
            document.getElementById('quote-responsible').value = quote.responsible || '';
            document.getElementById('quote-description').value = quote.description;
            document.getElementById('quote-observations').value = quote.observations || '';
        } else {
            title.textContent = 'Novo Orçamento';
            document.getElementById('quote-id').value = this.generateQuoteId();
        }

        modal.classList.add('active');
    }

    closeQuoteModal() {
        document.getElementById('quote-modal').classList.remove('active');
        this.currentEditingQuote = null;
    }

    generateQuoteId() {
        const year = new Date().getFullYear();
        const count = this.quotes.length + 1;
        return `ORC-${year}-${count.toString().padStart(3, '0')}`;
    }

    saveQuote() {
        const quote = {
            id: this.currentEditingQuote ? this.currentEditingQuote.id : Date.now(),
            quoteId: document.getElementById('quote-id').value,
            client: document.getElementById('quote-client').value,
            contact: document.getElementById('quote-contact').value,
            email: document.getElementById('quote-email').value,
            phone: document.getElementById('quote-phone').value,
            sector: document.getElementById('quote-sector').value,
            value: this.parseMoneyValue(document.getElementById('quote-value').value),
            probability: parseInt(document.getElementById('quote-probability').value),
            status: document.getElementById('quote-status').value,
            sendDate: document.getElementById('quote-send-date').value,
            followupDate: document.getElementById('quote-followup-date').value,
            responsible: document.getElementById('quote-responsible').value,
            description: document.getElementById('quote-description').value,
            observations: document.getElementById('quote-observations').value,
            createdAt: this.currentEditingQuote ? this.currentEditingQuote.createdAt : new Date().toISOString()
        };

        if (this.currentEditingQuote) {
            const index = this.quotes.findIndex(q => q.id === this.currentEditingQuote.id);
            this.quotes[index] = quote;
        } else {
            this.quotes.push(quote);
        }

        this.saveToStorage();
        this.renderQuotes();
        this.updateDashboardKPIs();
        this.renderCharts();
        this.closeQuoteModal();
        this.showNotification('Orçamento salvo com sucesso!', 'success');
    }

    deleteQuote(id) {
        if (confirm('Tem certeza que deseja excluir este orçamento?')) {
            this.quotes = this.quotes.filter(q => q.id !== id);
            this.saveToStorage();
            this.renderQuotes();
            this.updateDashboardKPIs();
            this.renderCharts();
            this.showNotification('Orçamento excluído com sucesso!', 'success');
        }
    }

    renderQuotes() {
        const tbody = document.getElementById('quotes-table-body');
        let filteredQuotes = this.getFilteredQuotes();

        tbody.innerHTML = '';

        filteredQuotes.forEach(quote => {
            const expectedValue = quote.value * (quote.probability / 100);
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${quote.quoteId}</td>
                <td>${quote.client}</td>
                <td>${quote.sector}</td>
                <td>${this.formatMoney(quote.value)}</td>
                <td>${quote.probability}%</td>
                <td>${this.formatMoney(expectedValue)}</td>
                <td><span class="status-badge ${quote.status.toLowerCase().replace(/[^a-z0-9]/g, '-')}">${quote.status}</span></td>
                <td class="actions">
                    <button class="btn btn--sm btn--secondary" onclick="app.openQuoteModal(${JSON.stringify(quote).replace(/"/g, '&quot;')})">Editar</button>
                    <button class="btn btn--sm btn--outline" onclick="app.deleteQuote(${quote.id})">Excluir</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    getFilteredQuotes() {
        let filtered = [...this.quotes];

        const statusFilter = document.getElementById('filter-quote-status').value;
        const sectorFilter = document.getElementById('filter-quote-setor').value;

        if (statusFilter) {
            filtered = filtered.filter(q => q.status === statusFilter);
        }

        if (sectorFilter) {
            filtered = filtered.filter(q => q.sector === sectorFilter);
        }

        return filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    clearQuoteFilters() {
        document.getElementById('filter-quote-status').value = '';
        document.getElementById('filter-quote-setor').value = '';
        this.renderQuotes();
    }

    // Dashboard KPIs
    updateDashboardKPIs() {
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();

        // Financial KPIs
        const totalEntradas = this.transactions
            .filter(t => t.type === 'entrada' && (t.status === 'Recebido'))
            .reduce((sum, t) => sum + t.value, 0);

        const totalSaidas = this.transactions
            .filter(t => t.type === 'saida' && (t.status === 'Pago'))
            .reduce((sum, t) => sum + t.value, 0);

        const saldoAtual = totalEntradas - totalSaidas;

        const entradasMes = this.transactions
            .filter(t => {
                const date = new Date(t.date);
                return t.type === 'entrada' && 
                       date.getMonth() === currentMonth && 
                       date.getFullYear() === currentYear;
            })
            .reduce((sum, t) => sum + t.value, 0);

        const saidasMes = this.transactions
            .filter(t => {
                const date = new Date(t.date);
                return t.type === 'saida' && 
                       date.getMonth() === currentMonth && 
                       date.getFullYear() === currentYear;
            })
            .reduce((sum, t) => sum + t.value, 0);

        const aReceber = this.transactions
            .filter(t => t.type === 'entrada' && t.status === 'A Receber')
            .reduce((sum, t) => sum + t.value, 0);

        // Commercial KPIs
        const totalOrcamentos = this.quotes.length;
        const valorPipeline = this.quotes
            .filter(q => !['Fechado-Ganho', 'Fechado-Perdido'].includes(q.status))
            .reduce((sum, q) => sum + q.value, 0);

        const orcamentosFechados = this.quotes.filter(q => q.status === 'Fechado-Ganho').length;
        const taxaConversao = totalOrcamentos > 0 ? (orcamentosFechados / totalOrcamentos * 100) : 0;

        const previsaoEntrada = this.quotes
            .filter(q => !['Fechado-Ganho', 'Fechado-Perdido'].includes(q.status))
            .reduce((sum, q) => sum + (q.value * q.probability / 100), 0);

        // Update DOM
        document.getElementById('saldo-atual').textContent = this.formatMoney(saldoAtual);
        document.getElementById('entradas-mes').textContent = this.formatMoney(entradasMes);
        document.getElementById('saidas-mes').textContent = this.formatMoney(saidasMes);
        document.getElementById('a-receber').textContent = this.formatMoney(aReceber);
        document.getElementById('total-orcamentos').textContent = totalOrcamentos;
        document.getElementById('valor-pipeline').textContent = this.formatMoney(valorPipeline);
        document.getElementById('taxa-conversao').textContent = `${taxaConversao.toFixed(1)}%`;
        document.getElementById('previsao-entrada').textContent = this.formatMoney(previsaoEntrada);
    }

    // Charts
    renderCharts() {
        this.renderRevenueChart();
        this.renderQuotesChart();
    }

    renderRevenueChart() {
        const canvas = document.getElementById('chart-receita');
        const ctx = canvas.getContext('2d');
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const revenueBysector = {};
        this.categoryMap.entrada.forEach(sector => {
            revenueBysector[sector] = this.transactions
                .filter(t => t.type === 'entrada' && t.category === sector && t.status === 'Recebido')
                .reduce((sum, t) => sum + t.value, 0);
        });

        const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5'];
        const data = Object.values(revenueBysector);
        const labels = Object.keys(revenueBysector);
        
        if (data.some(value => value > 0)) {
            this.drawPieChart(ctx, data, labels, colors, canvas.width, canvas.height);
        } else {
            this.drawNoDataMessage(ctx, canvas.width, canvas.height, 'Nenhum dado disponível');
        }
    }

    renderQuotesChart() {
        const canvas = document.getElementById('chart-orcamentos');
        const ctx = canvas.getContext('2d');
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const quotesByStatus = {};
        this.quoteStatuses.forEach(status => {
            quotesByStatus[status] = this.quotes.filter(q => q.status === status).length;
        });

        const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545'];
        const data = Object.values(quotesByStatus);
        const labels = Object.keys(quotesByStatus);
        
        if (data.some(value => value > 0)) {
            this.drawBarChart(ctx, data, labels, colors, canvas.width, canvas.height);
        } else {
            this.drawNoDataMessage(ctx, canvas.width, canvas.height, 'Nenhum orçamento cadastrado');
        }
    }

    drawPieChart(ctx, data, labels, colors, width, height) {
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(centerX, centerY) - 40;
        
        const total = data.reduce((sum, value) => sum + value, 0);
        
        if (total === 0) {
            this.drawNoDataMessage(ctx, width, height, 'Nenhum dado disponível');
            return;
        }
        
        let currentAngle = -Math.PI / 2;
        
        data.forEach((value, index) => {
            const sliceAngle = (value / total) * 2 * Math.PI;
            
            // Draw slice
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
            ctx.lineTo(centerX, centerY);
            ctx.fillStyle = colors[index % colors.length];
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2;
            ctx.stroke();
            
            currentAngle += sliceAngle;
        });
        
        // Draw legend
        this.drawLegend(ctx, labels, colors, data, total, width, height, true);
    }

    drawBarChart(ctx, data, labels, colors, width, height) {
        const margin = 60;
        const chartWidth = width - margin * 2;
        const chartHeight = height - margin * 2;
        const barWidth = chartWidth / data.length * 0.8;
        const maxValue = Math.max(...data);
        
        if (maxValue === 0) {
            this.drawNoDataMessage(ctx, width, height, 'Nenhum orçamento cadastrado');
            return;
        }
        
        // Draw bars
        data.forEach((value, index) => {
            const barHeight = (value / maxValue) * chartHeight;
            const x = margin + (index * chartWidth / data.length) + (chartWidth / data.length - barWidth) / 2;
            const y = height - margin - barHeight;
            
            ctx.fillStyle = colors[index % colors.length];
            ctx.fillRect(x, y, barWidth, barHeight);
            
            // Draw value on top of bar
            ctx.fillStyle = '#333';
            ctx.font = '12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(value.toString(), x + barWidth / 2, y - 5);
        });
        
        // Draw labels
        ctx.fillStyle = '#666';
        ctx.font = '10px Arial';
        ctx.textAlign = 'center';
        labels.forEach((label, index) => {
            const x = margin + (index * chartWidth / data.length) + chartWidth / data.length / 2;
            const words = label.split(' ');
            words.forEach((word, wordIndex) => {
                ctx.fillText(word, x, height - margin + 15 + (wordIndex * 12));
            });
        });
    }

    drawLegend(ctx, labels, colors, data, total, width, height, isPercentage = false) {
        const legendX = width - 150;
        const legendY = 20;
        
        ctx.font = '12px Arial';
        ctx.textAlign = 'left';
        
        labels.forEach((label, index) => {
            const y = legendY + index * 25;
            
            // Draw color box
            ctx.fillStyle = colors[index % colors.length];
            ctx.fillRect(legendX, y, 15, 15);
            
            // Draw text
            ctx.fillStyle = '#333';
            const percentage = isPercentage ? ` (${((data[index] / total) * 100).toFixed(1)}%)` : '';
            ctx.fillText(`${label}${percentage}`, legendX + 20, y + 12);
        });
    }

    drawNoDataMessage(ctx, width, height, message) {
        ctx.fillStyle = '#666';
        ctx.font = '16px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(message, width / 2, height / 2);
    }

    // Data Management
    saveToStorage() {
        localStorage.setItem('transactions', JSON.stringify(this.transactions));
        localStorage.setItem('quotes', JSON.stringify(this.quotes));
    }

    // Export Functions
    exportFinancialData() {
        const headers = ['Data', 'Tipo', 'Categoria', 'Descrição', 'Valor', 'Cliente/Fornecedor', 'Status', 'Observações'];
        const data = this.transactions.map(t => [
            new Date(t.date).toLocaleDateString('pt-BR'),
            t.type === 'entrada' ? 'Entrada' : 'Saída',
            t.category,
            t.description,
            this.formatMoney(t.value),
            t.client || '',
            t.status,
            t.observations || ''
        ]);

        this.downloadCSV([headers, ...data], 'relatorio_financeiro.csv');
    }

    exportCRMData() {
        const headers = ['ID', 'Cliente', 'Contato', 'Email', 'Telefone', 'Setor', 'Valor', 'Probabilidade', 'Valor Previsto', 'Status', 'Data Envio', 'Follow-up', 'Responsável', 'Descrição'];
        const data = this.quotes.map(q => [
            q.quoteId,
            q.client,
            q.contact || '',
            q.email || '',
            q.phone || '',
            q.sector,
            this.formatMoney(q.value),
            `${q.probability}%`,
            this.formatMoney(q.value * q.probability / 100),
            q.status,
            q.sendDate ? new Date(q.sendDate).toLocaleDateString('pt-BR') : '',
            q.followupDate ? new Date(q.followupDate).toLocaleDateString('pt-BR') : '',
            q.responsible || '',
            q.description
        ]);

        this.downloadCSV([headers, ...data], 'relatorio_crm.csv');
    }

    downloadCSV(data, filename) {
        const csvContent = data.map(row => 
            row.map(field => `"${field}"`).join(',')
        ).join('\n');

        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', filename);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        this.showNotification('Arquivo exportado com sucesso!', 'success');
    }

    createBackup() {
        const backup = {
            transactions: this.transactions,
            quotes: this.quotes,
            timestamp: new Date().toISOString(),
            version: '1.0'
        };

        const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
        const link = document.createElement('a');
        
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', `backup_engetrica_${new Date().toISOString().split('T')[0]}.json`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        this.showNotification('Backup criado com sucesso!', 'success');
    }

    restoreBackup(file) {
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const backup = JSON.parse(e.target.result);
                
                if (confirm('Tem certeza que deseja restaurar o backup? Todos os dados atuais serão substituídos.')) {
                    this.transactions = backup.transactions || [];
                    this.quotes = backup.quotes || [];
                    this.saveToStorage();
                    this.renderTransactions();
                    this.renderQuotes();
                    this.updateDashboardKPIs();
                    this.renderCharts();
                    this.showNotification('Backup restaurado com sucesso!', 'success');
                }
            } catch (error) {
                this.showNotification('Erro ao restaurar backup. Arquivo inválido.', 'error');
            }
        };
        reader.readAsText(file);
    }

    // Notifications
    showNotification(message, type = 'info') {
        const notification = document.getElementById('notification');
        notification.textContent = message;
        notification.className = `notification ${type} show`;

        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }

    renderDashboard() {
        // Dashboard is rendered by updateDashboardKPIs and renderCharts
    }
}

// Initialize the application
const app = new EngElectricaApp();