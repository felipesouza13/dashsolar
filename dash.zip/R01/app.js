// Sistema de Gestão para Empresa de Engenharia Elétrica
class EngElectricaSystem {
    constructor() {
        // Inicialização dos dados
        this.currentUser = null;
        this.currentEditingId = null;
        this.currentModal = null;
        
        // Verificar se existe dados iniciais, se não, criar
        this.initializeData();
        
        // Configurar listeners
        this.setupEventListeners();
        
        // Verificar se usuário já está logado
        this.checkLoginStatus();
    }

    // Inicializar dados exemplo se não existirem
    initializeData() {
        // Colaboradores iniciais
        if (!localStorage.getItem('colaboradores')) {
            const colaboradoresIniciais = [
                {
                    id: 1,
                    nome: "Administrador",
                    email: "admin@empresa.com",
                    senha: "admin123",
                    cargo: "Administrador",
                    setor: "Geral",
                    telefone: "(62) 99999-9999",
                    dataAdmissao: "2024-01-01",
                    status: "Ativo",
                    nivelAcesso: "Admin",
                    observacoes: "Usuário administrador padrão"
                },
                {
                    id: 2,
                    nome: "João Silva",
                    email: "joao@empresa.com",
                    senha: "123456",
                    cargo: "Engenheiro Elétrico",
                    setor: "Projetos",
                    telefone: "(62) 98888-8888",
                    dataAdmissao: "2024-02-01",
                    status: "Ativo",
                    nivelAcesso: "Usuário",
                    observacoes: "Engenheiro responsável por projetos elétricos"
                }
            ];
            localStorage.setItem('colaboradores', JSON.stringify(colaboradoresIniciais));
        }

        // Transações iniciais
        if (!localStorage.getItem('transacoes')) {
            const transacoesIniciais = [
                {
                    id: 1,
                    tipo: "Entrada",
                    categoria: "Energia Solar",
                    descricao: "Instalação sistema fotovoltaico 10kW",
                    clienteFornecedor: "João da Silva",
                    valor: 45000,
                    data: "2024-05-15",
                    status: "Recebido",
                    observacoes: "Projeto residencial concluído"
                },
                {
                    id: 2,
                    tipo: "Saída",
                    categoria: "Materiais",
                    descricao: "Compra de painéis solares",
                    clienteFornecedor: "Solar Tech Ltda",
                    valor: 25000,
                    data: "2024-05-10",
                    status: "Pago",
                    observacoes: "10 painéis 450W cada"
                }
            ];
            localStorage.setItem('transacoes', JSON.stringify(transacoesIniciais));
        }

        // Orçamentos iniciais
        if (!localStorage.getItem('orcamentos')) {
            const orcamentosIniciais = [
                {
                    id: "ORC001",
                    cliente: "Maria Santos",
                    email: "maria@email.com",
                    telefone: "(62) 97777-7777",
                    setor: "Energia Solar",
                    descricao: "Sistema fotovoltaico 15kW residencial",
                    valor: 67500,
                    status: "Em Análise",
                    probabilidade: 70,
                    responsavel: "João Silva",
                    dataCriacao: "2024-05-20",
                    followUp: "2024-05-25",
                    observacoes: "Cliente interessado, aguardando aprovação financiamento"
                }
            ];
            localStorage.setItem('orcamentos', JSON.stringify(orcamentosIniciais));
        }

        // Obras iniciais
        if (!localStorage.getItem('obras')) {
            const obrasIniciais = [
                {
                    id: 1,
                    codigo: "2024-001",
                    nome: "Instalação Solar Residencial",
                    cliente: "João da Silva",
                    tipoServico: "Energia Solar",
                    endereco: "Rua das Flores, 123, Setor Sul, Goiânia-GO",
                    dataInicio: "2024-05-01",
                    dataFim: "2024-05-30",
                    status: "Concluída",
                    valorContrato: 45000,
                    responsavelTecnico: "João Silva",
                    equipe: "João Silva, Pedro Costa",
                    progresso: 100,
                    observacoes: "Obra concluída com sucesso"
                },
                {
                    id: 2,
                    codigo: "2024-002",
                    nome: "Projeto Elétrico Comercial",
                    cliente: "Empresa ABC",
                    tipoServico: "Projetos Elétricos",
                    endereco: "Av. Principal, 456, Centro, Goiânia-GO",
                    dataInicio: "2024-05-15",
                    dataFim: "2024-06-15",
                    status: "Em Andamento",
                    valorContrato: 85000,
                    responsavelTecnico: "João Silva",
                    equipe: "João Silva, Ana Costa, Carlos Lima",
                    progresso: 65,
                    observacoes: "Projeto em andamento, dentro do prazo"
                }
            ];
            localStorage.setItem('obras', JSON.stringify(obrasIniciais));
        }
    }

    // Configurar todos os event listeners
    setupEventListeners() {
        // Login
        document.getElementById('login-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Logout
        document.getElementById('logout-btn').addEventListener('click', () => {
            this.handleLogout();
        });

        // Navigation tabs
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const tabName = e.currentTarget.getAttribute('data-tab');
                this.switchTab(tabName);
            });
        });

        // Transações
        document.getElementById('nova-transacao-btn').addEventListener('click', () => {
            this.openTransacaoModal();
        });
        
        document.getElementById('close-transacao-modal').addEventListener('click', () => {
            this.closeModal('transacao-modal');
        });
        
        document.getElementById('cancel-transacao').addEventListener('click', () => {
            this.closeModal('transacao-modal');
        });
        
        document.getElementById('transacao-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveTransacao();
        });

        // Orçamentos
        document.getElementById('novo-orcamento-btn').addEventListener('click', () => {
            this.openOrcamentoModal();
        });
        
        document.getElementById('close-orcamento-modal').addEventListener('click', () => {
            this.closeModal('orcamento-modal');
        });
        
        document.getElementById('cancel-orcamento').addEventListener('click', () => {
            this.closeModal('orcamento-modal');
        });
        
        document.getElementById('orcamento-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveOrcamento();
        });

        // Obras
        document.getElementById('nova-obra-btn').addEventListener('click', () => {
            this.openObraModal();
        });
        
        document.getElementById('close-obra-modal').addEventListener('click', () => {
            this.closeModal('obra-modal');
        });
        
        document.getElementById('cancel-obra').addEventListener('click', () => {
            this.closeModal('obra-modal');
        });
        
        document.getElementById('obra-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveObra();
        });

        // Colaboradores
        document.getElementById('novo-colaborador-btn').addEventListener('click', () => {
            this.openColaboradorModal();
        });
        
        document.getElementById('close-colaborador-modal').addEventListener('click', () => {
            this.closeModal('colaborador-modal');
        });
        
        document.getElementById('cancel-colaborador').addEventListener('click', () => {
            this.closeModal('colaborador-modal');
        });
        
        document.getElementById('colaborador-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveColaborador();
        });

        // Filtros
        document.getElementById('filter-tipo')?.addEventListener('change', () => {
            this.renderTransacoes();
        });
        
        document.getElementById('filter-status')?.addEventListener('change', () => {
            this.renderTransacoes();
        });
        
        document.getElementById('clear-filters')?.addEventListener('click', () => {
            document.getElementById('filter-tipo').value = '';
            document.getElementById('filter-status').value = '';
            this.renderTransacoes();
        });

        // Tipo de transação - atualizar categorias e status
        document.getElementById('transacao-tipo').addEventListener('change', (e) => {
            this.updateTransacaoOptions(e.target.value);
        });

        // Fechar modal clicando fora
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
        });
    }

    // Verificar status de login
    checkLoginStatus() {
        const savedUser = localStorage.getItem('currentUser');
        if (savedUser) {
            this.currentUser = JSON.parse(savedUser);
            this.showMainSystem();
        } else {
            this.showLoginScreen();
        }
    }

    // Lidar com login
    handleLogin() {
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('login-error');

        const colaboradores = JSON.parse(localStorage.getItem('colaboradores')) || [];
        const user = colaboradores.find(c => c.email === email && c.senha === password && c.status === 'Ativo');

        if (user) {
            this.currentUser = user;
            localStorage.setItem('currentUser', JSON.stringify(user));
            this.showMainSystem();
            errorDiv.style.display = 'none';
        } else {
            errorDiv.textContent = 'Email ou senha incorretos, ou usuário inativo.';
            errorDiv.style.display = 'block';
        }
    }

    // Lidar com logout
    handleLogout() {
        this.currentUser = null;
        localStorage.removeItem('currentUser');
        this.showLoginScreen();
    }

    // Mostrar tela de login
    showLoginScreen() {
        document.getElementById('login-screen').style.display = 'flex';
        document.getElementById('main-system').classList.add('hidden');
        document.getElementById('email').value = '';
        document.getElementById('password').value = '';
    }

    // Mostrar sistema principal
    showMainSystem() {
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('main-system').classList.remove('hidden');
        document.getElementById('logged-user').textContent = this.currentUser.nome;
        
        // Renderizar dados
        this.renderDashboard();
        this.renderTransacoes();
        this.renderOrcamentos();
        this.renderObras();
        this.renderColaboradores();
        this.updateAllKPIs();
    }

    // Trocar de aba
    switchTab(tabName) {
        // Remover active de todas as abas
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Ativar aba selecionada
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        document.getElementById(`${tabName}-tab`).classList.add('active');

        // Atualizar dados específicos da aba
        if (tabName === 'dashboard') {
            this.updateAllKPIs();
        }
    }

    // Renderizar Dashboard
    renderDashboard() {
        this.updateAllKPIs();
    }

    // Atualizar todos os KPIs
    updateAllKPIs() {
        this.updateFinancialKPIs();
        this.updateCommercialKPIs();
        this.updateOperationalKPIs();
    }

    // Atualizar KPIs Financeiros
    updateFinancialKPIs() {
        const transacoes = JSON.parse(localStorage.getItem('transacoes')) || [];
        
        const entradas = transacoes.filter(t => t.tipo === 'Entrada');
        const saidas = transacoes.filter(t => t.tipo === 'Saída');
        
        const totalEntradas = entradas.reduce((sum, t) => sum + parseFloat(t.valor || 0), 0);
        const totalSaidas = saidas.reduce((sum, t) => sum + parseFloat(t.valor || 0), 0);
        const saldoAtual = totalEntradas - totalSaidas;
        
        const contasReceber = entradas.filter(t => t.status === 'A Receber').reduce((sum, t) => sum + parseFloat(t.valor || 0), 0);
        const contasPagar = saidas.filter(t => t.status === 'A Pagar').reduce((sum, t) => sum + parseFloat(t.valor || 0), 0);
        
        const margemLucro = totalEntradas > 0 ? ((saldoAtual / totalEntradas) * 100) : 0;

        document.getElementById('saldo-atual').textContent = this.formatCurrency(saldoAtual);
        document.getElementById('total-entradas').textContent = this.formatCurrency(totalEntradas);
        document.getElementById('total-saidas').textContent = this.formatCurrency(totalSaidas);
        document.getElementById('contas-receber').textContent = this.formatCurrency(contasReceber);
        document.getElementById('contas-pagar').textContent = this.formatCurrency(contasPagar);
        document.getElementById('margem-lucro').textContent = margemLucro.toFixed(1) + '%';

        // Atualizar resumo mensal
        const hoje = new Date();
        const mesAtual = hoje.getMonth();
        const anoAtual = hoje.getFullYear();
        
        const transacoesMes = transacoes.filter(t => {
            const dataTransacao = new Date(t.data);
            return dataTransacao.getMonth() === mesAtual && dataTransacao.getFullYear() === anoAtual;
        });
        
        const entradasMes = transacoesMes.filter(t => t.tipo === 'Entrada').reduce((sum, t) => sum + parseFloat(t.valor || 0), 0);
        const saidasMes = transacoesMes.filter(t => t.tipo === 'Saída').reduce((sum, t) => sum + parseFloat(t.valor || 0), 0);
        const resultadoMes = entradasMes - saidasMes;

        if (document.getElementById('entradas-mes')) {
            document.getElementById('entradas-mes').textContent = this.formatCurrency(entradasMes);
            document.getElementById('saidas-mes').textContent = this.formatCurrency(saidasMes);
            document.getElementById('resultado-mes').textContent = this.formatCurrency(resultadoMes);
        }
    }

    // Atualizar KPIs Comerciais
    updateCommercialKPIs() {
        const orcamentos = JSON.parse(localStorage.getItem('orcamentos')) || [];
        
        const totalOrcamentos = orcamentos.length;
        const valorPipeline = orcamentos.reduce((sum, o) => sum + parseFloat(o.valor || 0), 0);
        const previsaoEntrada = orcamentos.reduce((sum, o) => sum + (parseFloat(o.valor || 0) * (parseFloat(o.probabilidade || 0) / 100)), 0);
        
        const orcamentosFechados = orcamentos.filter(o => o.status === 'Fechado' || o.status === 'Aprovado');
        const taxaConversao = totalOrcamentos > 0 ? (orcamentosFechados.length / totalOrcamentos * 100) : 0;

        document.getElementById('total-orcamentos').textContent = totalOrcamentos;
        document.getElementById('valor-pipeline').textContent = this.formatCurrency(valorPipeline);
        document.getElementById('taxa-conversao').textContent = taxaConversao.toFixed(1) + '%';
        document.getElementById('previsao-entrada').textContent = this.formatCurrency(previsaoEntrada);

        // Atualizar resumo CRM
        if (document.getElementById('pipeline-total')) {
            const orcamentosAtivos = orcamentos.filter(o => !['Rejeitado', 'Fechado'].includes(o.status)).length;
            document.getElementById('pipeline-total').textContent = this.formatCurrency(valorPipeline);
            document.getElementById('orcamentos-ativos').textContent = orcamentosAtivos;
            document.getElementById('taxa-conversao-crm').textContent = taxaConversao.toFixed(1) + '%';
        }
    }

    // Atualizar KPIs Operacionais
    updateOperationalKPIs() {
        const obras = JSON.parse(localStorage.getItem('obras')) || [];
        const colaboradores = JSON.parse(localStorage.getItem('colaboradores')) || [];
        
        const projetosAtivos = obras.filter(o => o.status === 'Em Andamento').length;
        const obrasAndamento = obras.filter(o => o.status === 'Em Andamento').length;
        const colaboradoresAtivos = colaboradores.filter(c => c.status === 'Ativo').length;
        const laudosRealizados = obras.filter(o => o.tipoServico === 'Laudos' && o.status === 'Concluída').length;

        document.getElementById('projetos-ativos').textContent = projetosAtivos;
        document.getElementById('obras-andamento').textContent = obrasAndamento;
        document.getElementById('colaboradores-ativos').textContent = colaboradoresAtivos;
        document.getElementById('laudos-realizados').textContent = laudosRealizados;

        // Atualizar resumos das obras
        if (document.getElementById('obras-planejamento')) {
            const obrasPlanejamento = obras.filter(o => o.status === 'Planejamento').length;
            const obrasConcluidas = obras.filter(o => o.status === 'Concluída').length;
            
            document.getElementById('obras-planejamento').textContent = obrasPlanejamento;
            document.getElementById('obras-andamento-count').textContent = obrasAndamento;
            document.getElementById('obras-concluidas').textContent = obrasConcluidas;
        }

        // Atualizar resumos dos colaboradores
        if (document.getElementById('colaboradores-ativos-count')) {
            const colaboradoresAdmin = colaboradores.filter(c => c.nivelAcesso === 'Admin' && c.status === 'Ativo').length;
            const colaboradoresUsers = colaboradores.filter(c => c.nivelAcesso === 'Usuário' && c.status === 'Ativo').length;
            
            document.getElementById('colaboradores-ativos-count').textContent = colaboradoresAtivos;
            document.getElementById('colaboradores-admin').textContent = colaboradoresAdmin;
            document.getElementById('colaboradores-users').textContent = colaboradoresUsers;
        }
    }

    // Renderizar Transações
    renderTransacoes() {
        const transacoes = JSON.parse(localStorage.getItem('transacoes')) || [];
        const tbody = document.getElementById('transacoes-list');
        
        // Aplicar filtros
        const filterTipo = document.getElementById('filter-tipo')?.value || '';
        const filterStatus = document.getElementById('filter-status')?.value || '';
        
        const transacoesFiltradas = transacoes.filter(t => {
            return (!filterTipo || t.tipo === filterTipo) && 
                   (!filterStatus || t.status === filterStatus);
        });

        tbody.innerHTML = transacoesFiltradas.map(transacao => `
            <tr>
                <td>${this.formatDate(transacao.data)}</td>
                <td><span class="status-badge ${transacao.tipo.toLowerCase()}">${transacao.tipo}</span></td>
                <td>${transacao.categoria}</td>
                <td>${transacao.descricao}</td>
                <td>${transacao.clienteFornecedor}</td>
                <td>${this.formatCurrency(transacao.valor)}</td>
                <td><span class="status-badge ${transacao.status.toLowerCase().replace(' ', '-')}">${transacao.status}</span></td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn--sm btn--secondary" onclick="system.editTransacao(${transacao.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn--sm btn--outline" onclick="system.deleteTransacao(${transacao.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Renderizar Orçamentos
    renderOrcamentos() {
        const orcamentos = JSON.parse(localStorage.getItem('orcamentos')) || [];
        const tbody = document.getElementById('orcamentos-list');

        tbody.innerHTML = orcamentos.map(orcamento => `
            <tr>
                <td>${orcamento.id}</td>
                <td>${orcamento.cliente}</td>
                <td>${orcamento.setor}</td>
                <td>${this.formatCurrency(orcamento.valor)}</td>
                <td><span class="status-badge ${orcamento.status.toLowerCase().replace(' ', '-')}">${orcamento.status}</span></td>
                <td>${orcamento.probabilidade}%</td>
                <td>${orcamento.responsavel}</td>
                <td>${this.formatDate(orcamento.dataCriacao)}</td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn--sm btn--secondary" onclick="system.editOrcamento('${orcamento.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn--sm btn--outline" onclick="system.deleteOrcamento('${orcamento.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Renderizar Obras
    renderObras() {
        const obras = JSON.parse(localStorage.getItem('obras')) || [];
        const tbody = document.getElementById('obras-list');

        tbody.innerHTML = obras.map(obra => `
            <tr>
                <td>${obra.codigo}</td>
                <td>${obra.nome}</td>
                <td>${obra.cliente}</td>
                <td>${obra.tipoServico}</td>
                <td><span class="status-badge ${obra.status.toLowerCase().replace(' ', '-')}">${obra.status}</span></td>
                <td>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${obra.progresso}%"></div>
                    </div>
                    ${obra.progresso}%
                </td>
                <td>${this.formatCurrency(obra.valorContrato)}</td>
                <td>${obra.responsavelTecnico}</td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn--sm btn--secondary" onclick="system.editObra(${obra.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn--sm btn--outline" onclick="system.deleteObra(${obra.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Renderizar Colaboradores
    renderColaboradores() {
        const colaboradores = JSON.parse(localStorage.getItem('colaboradores')) || [];
        const tbody = document.getElementById('colaboradores-list');

        tbody.innerHTML = colaboradores.map(colaborador => `
            <tr>
                <td>${colaborador.nome}</td>
                <td>${colaborador.email}</td>
                <td>${colaborador.cargo}</td>
                <td>${colaborador.setor}</td>
                <td>${colaborador.telefone || '-'}</td>
                <td><span class="status-badge ${colaborador.status.toLowerCase()}">${colaborador.status}</span></td>
                <td>${colaborador.nivelAcesso}</td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn--sm btn--secondary" onclick="system.editColaborador(${colaborador.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        ${colaborador.email !== 'admin@empresa.com' ? `
                            <button class="btn btn--sm btn--outline" onclick="system.deleteColaborador(${colaborador.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Abrir modal de transação
    openTransacaoModal(id = null) {
        this.currentEditingId = id;
        const modal = document.getElementById('transacao-modal');
        const title = document.getElementById('transacao-modal-title');
        const form = document.getElementById('transacao-form');
        
        form.reset();
        title.textContent = id ? 'Editar Transação' : 'Nova Transação';
        
        // Definir data atual como padrão
        document.getElementById('transacao-data').value = new Date().toISOString().split('T')[0];
        
        if (id) {
            const transacoes = JSON.parse(localStorage.getItem('transacoes')) || [];
            const transacao = transacoes.find(t => t.id === id);
            if (transacao) {
                document.getElementById('transacao-tipo').value = transacao.tipo;
                this.updateTransacaoOptions(transacao.tipo);
                document.getElementById('transacao-categoria').value = transacao.categoria;
                document.getElementById('transacao-descricao').value = transacao.descricao;
                document.getElementById('transacao-cliente').value = transacao.clienteFornecedor;
                document.getElementById('transacao-valor').value = transacao.valor;
                document.getElementById('transacao-data').value = transacao.data;
                document.getElementById('transacao-status').value = transacao.status;
                document.getElementById('transacao-observacoes').value = transacao.observacoes || '';
            }
        }
        
        this.openModal('transacao-modal');
    }

    // Atualizar opções de categoria e status baseado no tipo
    updateTransacaoOptions(tipo) {
        const categoriaSelect = document.getElementById('transacao-categoria');
        const statusSelect = document.getElementById('transacao-status');
        
        categoriaSelect.innerHTML = '<option value="">Selecione</option>';
        statusSelect.innerHTML = '<option value="">Selecione</option>';
        
        if (tipo === 'Entrada') {
            const categorias = ["Projetos Elétricos", "Energia Solar", "Laudos", "Execução de Serviços"];
            const status = ["Recebido", "A Receber", "Vencido"];
            
            categorias.forEach(cat => {
                categoriaSelect.innerHTML += `<option value="${cat}">${cat}</option>`;
            });
            
            status.forEach(st => {
                statusSelect.innerHTML += `<option value="${st}">${st}</option>`;
            });
        } else if (tipo === 'Saída') {
            const categorias = ["Materiais", "Pessoal", "Aluguel", "Equipamentos", "Tributos", "Outras Despesas"];
            const status = ["Pago", "A Pagar", "Vencido"];
            
            categorias.forEach(cat => {
                categoriaSelect.innerHTML += `<option value="${cat}">${cat}</option>`;
            });
            
            status.forEach(st => {
                statusSelect.innerHTML += `<option value="${st}">${st}</option>`;
            });
        }
    }

    // Salvar transação
    saveTransacao() {
        const form = document.getElementById('transacao-form');
        const formData = new FormData(form);
        
        const transacao = {
            id: this.currentEditingId || Date.now(),
            tipo: document.getElementById('transacao-tipo').value,
            categoria: document.getElementById('transacao-categoria').value,
            descricao: document.getElementById('transacao-descricao').value,
            clienteFornecedor: document.getElementById('transacao-cliente').value,
            valor: parseFloat(document.getElementById('transacao-valor').value),
            data: document.getElementById('transacao-data').value,
            status: document.getElementById('transacao-status').value,
            observacoes: document.getElementById('transacao-observacoes').value
        };

        const transacoes = JSON.parse(localStorage.getItem('transacoes')) || [];
        
        if (this.currentEditingId) {
            const index = transacoes.findIndex(t => t.id === this.currentEditingId);
            if (index !== -1) {
                transacoes[index] = transacao;
            }
        } else {
            transacoes.push(transacao);
        }
        
        localStorage.setItem('transacoes', JSON.stringify(transacoes));
        this.closeModal('transacao-modal');
        this.renderTransacoes();
        this.updateAllKPIs();
        this.showMessage('Transação salva com sucesso!', 'success');
    }

    // Editar transação
    editTransacao(id) {
        this.openTransacaoModal(id);
    }

    // Deletar transação
    deleteTransacao(id) {
        if (confirm('Tem certeza que deseja excluir esta transação?')) {
            const transacoes = JSON.parse(localStorage.getItem('transacoes')) || [];
            const novasTransacoes = transacoes.filter(t => t.id !== id);
            localStorage.setItem('transacoes', JSON.stringify(novasTransacoes));
            this.renderTransacoes();
            this.updateAllKPIs();
            this.showMessage('Transação excluída com sucesso!', 'success');
        }
    }

    // Abrir modal de orçamento
    openOrcamentoModal(id = null) {
        this.currentEditingId = id;
        const modal = document.getElementById('orcamento-modal');
        const title = document.getElementById('orcamento-modal-title');
        const form = document.getElementById('orcamento-form');
        
        form.reset();
        title.textContent = id ? 'Editar Orçamento' : 'Novo Orçamento';
        
        if (!id) {
            // Gerar ID automático para novo orçamento
            const orcamentos = JSON.parse(localStorage.getItem('orcamentos')) || [];
            const nextNumber = orcamentos.length + 1;
            document.getElementById('orcamento-id').value = `ORC${nextNumber.toString().padStart(3, '0')}`;
            document.getElementById('orcamento-responsavel').value = this.currentUser.nome;
        } else {
            const orcamentos = JSON.parse(localStorage.getItem('orcamentos')) || [];
            const orcamento = orcamentos.find(o => o.id === id);
            if (orcamento) {
                document.getElementById('orcamento-id').value = orcamento.id;
                document.getElementById('orcamento-cliente').value = orcamento.cliente;
                document.getElementById('orcamento-email').value = orcamento.email || '';
                document.getElementById('orcamento-telefone').value = orcamento.telefone || '';
                document.getElementById('orcamento-setor').value = orcamento.setor;
                document.getElementById('orcamento-descricao').value = orcamento.descricao;
                document.getElementById('orcamento-valor').value = orcamento.valor;
                document.getElementById('orcamento-status').value = orcamento.status;
                document.getElementById('orcamento-probabilidade').value = orcamento.probabilidade;
                document.getElementById('orcamento-responsavel').value = orcamento.responsavel;
                document.getElementById('orcamento-followup').value = orcamento.followUp || '';
                document.getElementById('orcamento-observacoes').value = orcamento.observacoes || '';
            }
        }
        
        this.openModal('orcamento-modal');
    }

    // Salvar orçamento
    saveOrcamento() {
        const orcamento = {
            id: document.getElementById('orcamento-id').value,
            cliente: document.getElementById('orcamento-cliente').value,
            email: document.getElementById('orcamento-email').value,
            telefone: document.getElementById('orcamento-telefone').value,
            setor: document.getElementById('orcamento-setor').value,
            descricao: document.getElementById('orcamento-descricao').value,
            valor: parseFloat(document.getElementById('orcamento-valor').value),
            status: document.getElementById('orcamento-status').value,
            probabilidade: parseInt(document.getElementById('orcamento-probabilidade').value),
            responsavel: document.getElementById('orcamento-responsavel').value,
            followUp: document.getElementById('orcamento-followup').value,
            observacoes: document.getElementById('orcamento-observacoes').value,
            dataCriacao: this.currentEditingId ? undefined : new Date().toISOString().split('T')[0]
        };

        // Manter data de criação original se editando
        if (this.currentEditingId) {
            const orcamentos = JSON.parse(localStorage.getItem('orcamentos')) || [];
            const orcamentoExistente = orcamentos.find(o => o.id === this.currentEditingId);
            if (orcamentoExistente) {
                orcamento.dataCriacao = orcamentoExistente.dataCriacao;
            }
        }

        const orcamentos = JSON.parse(localStorage.getItem('orcamentos')) || [];
        
        if (this.currentEditingId) {
            const index = orcamentos.findIndex(o => o.id === this.currentEditingId);
            if (index !== -1) {
                orcamentos[index] = orcamento;
            }
        } else {
            orcamentos.push(orcamento);
        }
        
        localStorage.setItem('orcamentos', JSON.stringify(orcamentos));
        this.closeModal('orcamento-modal');
        this.renderOrcamentos();
        this.updateAllKPIs();
        this.showMessage('Orçamento salvo com sucesso!', 'success');
    }

    // Editar orçamento
    editOrcamento(id) {
        this.openOrcamentoModal(id);
    }

    // Deletar orçamento
    deleteOrcamento(id) {
        if (confirm('Tem certeza que deseja excluir este orçamento?')) {
            const orcamentos = JSON.parse(localStorage.getItem('orcamentos')) || [];
            const novosOrcamentos = orcamentos.filter(o => o.id !== id);
            localStorage.setItem('orcamentos', JSON.stringify(novosOrcamentos));
            this.renderOrcamentos();
            this.updateAllKPIs();
            this.showMessage('Orçamento excluído com sucesso!', 'success');
        }
    }

    // Abrir modal de obra
    openObraModal(id = null) {
        this.currentEditingId = id;
        const modal = document.getElementById('obra-modal');
        const title = document.getElementById('obra-modal-title');
        const form = document.getElementById('obra-form');
        
        form.reset();
        title.textContent = id ? 'Editar Obra' : 'Nova Obra';
        
        if (!id) {
            // Gerar código automático para nova obra
            const obras = JSON.parse(localStorage.getItem('obras')) || [];
            const year = new Date().getFullYear();
            const nextNumber = obras.filter(o => o.codigo.startsWith(year.toString())).length + 1;
            document.getElementById('obra-codigo').value = `${year}-${nextNumber.toString().padStart(3, '0')}`;
            document.getElementById('obra-responsavel').value = this.currentUser.nome;
        } else {
            const obras = JSON.parse(localStorage.getItem('obras')) || [];
            const obra = obras.find(o => o.id === id);
            if (obra) {
                document.getElementById('obra-codigo').value = obra.codigo;
                document.getElementById('obra-nome').value = obra.nome;
                document.getElementById('obra-cliente').value = obra.cliente;
                document.getElementById('obra-tipo').value = obra.tipoServico;
                document.getElementById('obra-endereco').value = obra.endereco;
                document.getElementById('obra-data-inicio').value = obra.dataInicio;
                document.getElementById('obra-data-fim').value = obra.dataFim;
                document.getElementById('obra-status').value = obra.status;
                document.getElementById('obra-valor').value = obra.valorContrato;
                document.getElementById('obra-responsavel').value = obra.responsavelTecnico;
                document.getElementById('obra-equipe').value = obra.equipe || '';
                document.getElementById('obra-progresso').value = obra.progresso || 0;
                document.getElementById('obra-observacoes').value = obra.observacoes || '';
            }
        }
        
        this.openModal('obra-modal');
    }

    // Salvar obra
    saveObra() {
        const obra = {
            id: this.currentEditingId || Date.now(),
            codigo: document.getElementById('obra-codigo').value,
            nome: document.getElementById('obra-nome').value,
            cliente: document.getElementById('obra-cliente').value,
            tipoServico: document.getElementById('obra-tipo').value,
            endereco: document.getElementById('obra-endereco').value,
            dataInicio: document.getElementById('obra-data-inicio').value,
            dataFim: document.getElementById('obra-data-fim').value,
            status: document.getElementById('obra-status').value,
            valorContrato: parseFloat(document.getElementById('obra-valor').value),
            responsavelTecnico: document.getElementById('obra-responsavel').value,
            equipe: document.getElementById('obra-equipe').value,
            progresso: parseInt(document.getElementById('obra-progresso').value) || 0,
            observacoes: document.getElementById('obra-observacoes').value
        };

        const obras = JSON.parse(localStorage.getItem('obras')) || [];
        
        if (this.currentEditingId) {
            const index = obras.findIndex(o => o.id === this.currentEditingId);
            if (index !== -1) {
                obras[index] = obra;
            }
        } else {
            obras.push(obra);
        }
        
        localStorage.setItem('obras', JSON.stringify(obras));
        this.closeModal('obra-modal');
        this.renderObras();
        this.updateAllKPIs();
        this.showMessage('Obra salva com sucesso!', 'success');
    }

    // Editar obra
    editObra(id) {
        this.openObraModal(id);
    }

    // Deletar obra
    deleteObra(id) {
        if (confirm('Tem certeza que deseja excluir esta obra?')) {
            const obras = JSON.parse(localStorage.getItem('obras')) || [];
            const novasObras = obras.filter(o => o.id !== id);
            localStorage.setItem('obras', JSON.stringify(novasObras));
            this.renderObras();
            this.updateAllKPIs();
            this.showMessage('Obra excluída com sucesso!', 'success');
        }
    }

    // Abrir modal de colaborador
    openColaboradorModal(id = null) {
        this.currentEditingId = id;
        const modal = document.getElementById('colaborador-modal');
        const title = document.getElementById('colaborador-modal-title');
        const form = document.getElementById('colaborador-form');
        
        form.reset();
        title.textContent = id ? 'Editar Colaborador' : 'Novo Colaborador';
        
        // Definir data atual como padrão para admissão
        if (!id) {
            document.getElementById('colaborador-admissao').value = new Date().toISOString().split('T')[0];
            document.getElementById('colaborador-status').value = 'Ativo';
            document.getElementById('colaborador-nivel').value = 'Usuário';
        } else {
            const colaboradores = JSON.parse(localStorage.getItem('colaboradores')) || [];
            const colaborador = colaboradores.find(c => c.id === id);
            if (colaborador) {
                document.getElementById('colaborador-nome').value = colaborador.nome;
                document.getElementById('colaborador-email').value = colaborador.email;
                document.getElementById('colaborador-senha').value = colaborador.senha;
                document.getElementById('colaborador-cargo').value = colaborador.cargo;
                document.getElementById('colaborador-setor').value = colaborador.setor;
                document.getElementById('colaborador-telefone').value = colaborador.telefone || '';
                document.getElementById('colaborador-admissao').value = colaborador.dataAdmissao;
                document.getElementById('colaborador-status').value = colaborador.status;
                document.getElementById('colaborador-nivel').value = colaborador.nivelAcesso;
                document.getElementById('colaborador-observacoes').value = colaborador.observacoes || '';
            }
        }
        
        this.openModal('colaborador-modal');
    }

    // Salvar colaborador
    saveColaborador() {
        const colaborador = {
            id: this.currentEditingId || Date.now(),
            nome: document.getElementById('colaborador-nome').value,
            email: document.getElementById('colaborador-email').value,
            senha: document.getElementById('colaborador-senha').value,
            cargo: document.getElementById('colaborador-cargo').value,
            setor: document.getElementById('colaborador-setor').value,
            telefone: document.getElementById('colaborador-telefone').value,
            dataAdmissao: document.getElementById('colaborador-admissao').value,
            status: document.getElementById('colaborador-status').value,
            nivelAcesso: document.getElementById('colaborador-nivel').value,
            observacoes: document.getElementById('colaborador-observacoes').value
        };

        // Validar email único
        const colaboradores = JSON.parse(localStorage.getItem('colaboradores')) || [];
        const emailExiste = colaboradores.some(c => c.email === colaborador.email && c.id !== colaborador.id);
        
        if (emailExiste) {
            this.showMessage('Este email já está em uso por outro colaborador!', 'error');
            return;
        }

        if (this.currentEditingId) {
            const index = colaboradores.findIndex(c => c.id === this.currentEditingId);
            if (index !== -1) {
                colaboradores[index] = colaborador;
            }
        } else {
            colaboradores.push(colaborador);
        }
        
        localStorage.setItem('colaboradores', JSON.stringify(colaboradores));
        this.closeModal('colaborador-modal');
        this.renderColaboradores();
        this.updateAllKPIs();
        this.showMessage('Colaborador salvo com sucesso!', 'success');
    }

    // Editar colaborador
    editColaborador(id) {
        this.openColaboradorModal(id);
    }

    // Deletar colaborador
    deleteColaborador(id) {
        const colaboradores = JSON.parse(localStorage.getItem('colaboradores')) || [];
        const colaborador = colaboradores.find(c => c.id === id);
        
        if (colaborador && colaborador.email === 'admin@empresa.com') {
            this.showMessage('Não é possível excluir o administrador padrão!', 'error');
            return;
        }
        
        if (confirm('Tem certeza que deseja excluir este colaborador?')) {
            const novosColaboradores = colaboradores.filter(c => c.id !== id);
            localStorage.setItem('colaboradores', JSON.stringify(novosColaboradores));
            this.renderColaboradores();
            this.updateAllKPIs();
            this.showMessage('Colaborador excluído com sucesso!', 'success');
        }
    }

    // Abrir modal
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.add('active');
        modal.style.display = 'flex';
        this.currentModal = modalId;
    }

    // Fechar modal
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.remove('active');
        modal.style.display = 'none';
        this.currentModal = null;
        this.currentEditingId = null;
    }

    // Mostrar mensagem
    showMessage(message, type = 'info') {
        // Criar elemento de mensagem
        const messageEl = document.createElement('div');
        messageEl.className = `status status--${type}`;
        messageEl.textContent = message;
        messageEl.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        `;
        
        document.body.appendChild(messageEl);
        
        // Remover após 3 segundos
        setTimeout(() => {
            if (messageEl && messageEl.parentNode) {
                messageEl.parentNode.removeChild(messageEl);
            }
        }, 3000);
    }

    // Formatar moeda
    formatCurrency(value) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value || 0);
    }

    // Formatar data
    formatDate(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('pt-BR');
    }
}

// Inicializar sistema quando página carregar
let system;
document.addEventListener('DOMContentLoaded', () => {
    system = new EngElectricaSystem();
});